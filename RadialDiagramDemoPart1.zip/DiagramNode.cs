﻿// Arranging items radially around a central point using C#
// http://www.cyotek.com/blog/arranging-items-radially-around-a-central-point-using-csharp
// Copyright © 2017 Cyotek Ltd. All Rights Reserved.

// This work is licensed under the Creative Commons Attribution 4.0 International License.
// To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/.

using System.Collections.Generic;
using System.Drawing;

namespace Cyotek.Demo.RadialDiagram
{
  internal sealed class DiagramNode
  {
    #region Fields

    private Rectangle _bounds;

    private List<DiagramNode> _childNodes;

    private string _text;

    #endregion

    #region Constructors

    public DiagramNode()
    {
      _childNodes = new List<DiagramNode>();
    }

    public DiagramNode(string text)
      : this(text, Size.Empty)
    { }

    public DiagramNode(string text, Size size)
      : this()
    {
      _text = text;
      _bounds = new Rectangle(Point.Empty, size);
    }

    #endregion

    #region Properties

    public Rectangle Bounds
    {
      get { return _bounds; }
      set { _bounds = value; }
    }

    public Point Center
    {
      get { return new Point(_bounds.Left + _bounds.Width / 2, _bounds.Top + _bounds.Height / 2); }
    }

    public List<DiagramNode> ChildNodes
    {
      get { return _childNodes; }
      set { _childNodes = value; }
    }

    public int Height
    {
      get { return _bounds.Height; }
    }

    public int Left
    {
      get { return _bounds.Left; }
    }

    public Point Location
    {
      get { return _bounds.Location; }
      set { _bounds.Location = value; }
    }

    public Size Size
    {
      get { return _bounds.Size; }
      set { _bounds.Size = value; }
    }

    public string Text
    {
      get { return _text; }
      set { _text = value; }
    }

    public int Top
    {
      get { return _bounds.Top; }
    }

    public int Width
    {
      get { return _bounds.Width; }
    }

    #endregion
  }
}
