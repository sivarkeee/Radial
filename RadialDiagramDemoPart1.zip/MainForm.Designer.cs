﻿namespace Cyotek.Demo.RadialDiagram
{
  partial class MainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.splitContainer = new System.Windows.Forms.SplitContainer();
      this.label2 = new System.Windows.Forms.Label();
      this.maximumDistanceNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.drawBoundariesCheckBox = new System.Windows.Forms.CheckBox();
      this.label1 = new System.Windows.Forms.Label();
      this.rootTrackBar = new System.Windows.Forms.TrackBar();
      this.incrementTimer = new System.Windows.Forms.Timer(this.components);
      this.label3 = new System.Windows.Forms.Label();
      this.rootSizeNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.label4 = new System.Windows.Forms.Label();
      this.childSizeNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.diagramPanel = new Cyotek.Demo.RadialDiagram.BufferedPanel();
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
      this.splitContainer.Panel1.SuspendLayout();
      this.splitContainer.Panel2.SuspendLayout();
      this.splitContainer.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.maximumDistanceNumericUpDown)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.rootTrackBar)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.rootSizeNumericUpDown)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.childSizeNumericUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // splitContainer
      // 
      this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
      this.splitContainer.Location = new System.Drawing.Point(0, 0);
      this.splitContainer.Name = "splitContainer";
      // 
      // splitContainer.Panel1
      // 
      this.splitContainer.Panel1.Controls.Add(this.diagramPanel);
      // 
      // splitContainer.Panel2
      // 
      this.splitContainer.Panel2.Controls.Add(this.childSizeNumericUpDown);
      this.splitContainer.Panel2.Controls.Add(this.label4);
      this.splitContainer.Panel2.Controls.Add(this.rootSizeNumericUpDown);
      this.splitContainer.Panel2.Controls.Add(this.label3);
      this.splitContainer.Panel2.Controls.Add(this.label2);
      this.splitContainer.Panel2.Controls.Add(this.maximumDistanceNumericUpDown);
      this.splitContainer.Panel2.Controls.Add(this.drawBoundariesCheckBox);
      this.splitContainer.Panel2.Controls.Add(this.label1);
      this.splitContainer.Panel2.Controls.Add(this.rootTrackBar);
      this.splitContainer.Size = new System.Drawing.Size(658, 398);
      this.splitContainer.SplitterDistance = 358;
      this.splitContainer.TabIndex = 0;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(3, 169);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(153, 13);
      this.label2.TabIndex = 6;
      this.label2.Text = "Maximum &distance from center:";
      // 
      // maximumDistanceNumericUpDown
      // 
      this.maximumDistanceNumericUpDown.Location = new System.Drawing.Point(6, 185);
      this.maximumDistanceNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.maximumDistanceNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.maximumDistanceNumericUpDown.Name = "maximumDistanceNumericUpDown";
      this.maximumDistanceNumericUpDown.Size = new System.Drawing.Size(65, 20);
      this.maximumDistanceNumericUpDown.TabIndex = 7;
      this.maximumDistanceNumericUpDown.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
      this.maximumDistanceNumericUpDown.ValueChanged += new System.EventHandler(this.maximumDistanceNumericUpDown_ValueChanged);
      // 
      // drawBoundariesCheckBox
      // 
      this.drawBoundariesCheckBox.AutoSize = true;
      this.drawBoundariesCheckBox.Location = new System.Drawing.Point(6, 211);
      this.drawBoundariesCheckBox.Name = "drawBoundariesCheckBox";
      this.drawBoundariesCheckBox.Size = new System.Drawing.Size(106, 17);
      this.drawBoundariesCheckBox.TabIndex = 8;
      this.drawBoundariesCheckBox.Text = "Draw &boundaries";
      this.drawBoundariesCheckBox.UseVisualStyleBackColor = true;
      this.drawBoundariesCheckBox.CheckedChanged += new System.EventHandler(this.drawBoundariesCheckBox_CheckedChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(3, 9);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(116, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Number of &child nodes:";
      // 
      // rootTrackBar
      // 
      this.rootTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.rootTrackBar.Location = new System.Drawing.Point(6, 25);
      this.rootTrackBar.Maximum = 100;
      this.rootTrackBar.Name = "rootTrackBar";
      this.rootTrackBar.Size = new System.Drawing.Size(278, 45);
      this.rootTrackBar.TabIndex = 1;
      this.rootTrackBar.TickFrequency = 10;
      this.rootTrackBar.Value = 10;
      this.rootTrackBar.Scroll += new System.EventHandler(this.rootTrackBar_Scroll);
      this.rootTrackBar.ValueChanged += new System.EventHandler(this.rootTrackBar_Scroll);
      // 
      // incrementTimer
      // 
      this.incrementTimer.Interval = 500;
      this.incrementTimer.Tick += new System.EventHandler(this.incrementTimer_Tick);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(3, 73);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(54, 13);
      this.label3.TabIndex = 2;
      this.label3.Text = "Root &size:";
      // 
      // rootSizeNumericUpDown
      // 
      this.rootSizeNumericUpDown.Location = new System.Drawing.Point(6, 89);
      this.rootSizeNumericUpDown.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
      this.rootSizeNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.rootSizeNumericUpDown.Name = "rootSizeNumericUpDown";
      this.rootSizeNumericUpDown.Size = new System.Drawing.Size(65, 20);
      this.rootSizeNumericUpDown.TabIndex = 3;
      this.rootSizeNumericUpDown.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
      this.rootSizeNumericUpDown.ValueChanged += new System.EventHandler(this.rootSizeNumericUpDown_ValueChanged);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(3, 121);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(54, 13);
      this.label4.TabIndex = 4;
      this.label4.Text = "&Child size:";
      // 
      // childSizeNumericUpDown
      // 
      this.childSizeNumericUpDown.Location = new System.Drawing.Point(6, 137);
      this.childSizeNumericUpDown.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
      this.childSizeNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.childSizeNumericUpDown.Name = "childSizeNumericUpDown";
      this.childSizeNumericUpDown.Size = new System.Drawing.Size(65, 20);
      this.childSizeNumericUpDown.TabIndex = 5;
      this.childSizeNumericUpDown.Value = new decimal(new int[] {
            48,
            0,
            0,
            0});
      this.childSizeNumericUpDown.ValueChanged += new System.EventHandler(this.childSizeNumericUpDown_ValueChanged);
      // 
      // diagramPanel
      // 
      this.diagramPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.diagramPanel.Location = new System.Drawing.Point(0, 0);
      this.diagramPanel.Name = "diagramPanel";
      this.diagramPanel.Size = new System.Drawing.Size(358, 398);
      this.diagramPanel.TabIndex = 0;
      this.diagramPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.diagramPanel_Paint);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(658, 398);
      this.Controls.Add(this.splitContainer);
      this.Name = "MainForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "cyotek.com Radial Diagram Demonstration Part 1";
      this.splitContainer.Panel1.ResumeLayout(false);
      this.splitContainer.Panel2.ResumeLayout(false);
      this.splitContainer.Panel2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
      this.splitContainer.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.maximumDistanceNumericUpDown)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.rootTrackBar)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.rootSizeNumericUpDown)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.childSizeNumericUpDown)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer;
    private BufferedPanel diagramPanel;
    private System.Windows.Forms.TrackBar rootTrackBar;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.CheckBox drawBoundariesCheckBox;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.NumericUpDown maximumDistanceNumericUpDown;
    private System.Windows.Forms.Timer incrementTimer;
    private System.Windows.Forms.NumericUpDown childSizeNumericUpDown;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.NumericUpDown rootSizeNumericUpDown;
    private System.Windows.Forms.Label label3;
  }
}

